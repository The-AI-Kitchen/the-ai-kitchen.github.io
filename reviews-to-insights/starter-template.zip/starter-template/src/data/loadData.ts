import Papa from "papaparse"
import type { Codebook, Review, ThemeAssignment } from "../types"

interface RawReviewRow {
  review_id: string
  business_id: string
  business_name: string
  city: string
  state: string
  stars: string
  date: string
  text: string
  themes: string
  themes_with_quotes_json: string
}

function parseThemeJson(raw: string): ThemeAssignment[] {
  if (!raw || raw === "[]") return []
  try {
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

export async function loadReviews(): Promise<Review[]> {
  const res = await fetch(`${import.meta.env.BASE_URL}starbucks_reviews_coded.csv`)
  const csvText = await res.text()
  const parsed = Papa.parse<RawReviewRow>(csvText, {
    header: true,
    skipEmptyLines: true,
  })
  return parsed.data
    .filter((row) => row.review_id)
    .map((row) => ({
      review_id: row.review_id,
      business_id: row.business_id,
      business_name: row.business_name,
      city: row.city,
      state: row.state,
      stars: Number(row.stars),
      date: row.date,
      text: row.text,
      themes: row.themes ? row.themes.split("|").filter(Boolean) : [],
      themes_with_quotes: parseThemeJson(row.themes_with_quotes_json),
    }))
}

export async function loadCodebook(): Promise<Codebook> {
  const res = await fetch(`${import.meta.env.BASE_URL}starbucks_codebook.json`)
  return res.json()
}

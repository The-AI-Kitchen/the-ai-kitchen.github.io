import { useEffect, useMemo, useState } from "react"
import { ThemeFrequencyChart } from "./components/ThemeFrequencyChart"
import type { Codebook, Review } from "./types"
import { loadCodebook, loadReviews } from "./data/loadData"

// EXEC QUESTIONS this dashboard exists to answer.
// TODO #1: rewrite these to match the questions you'd ask if you were the
// Starbucks VP of Research. Three is the target. Then make sure every chart
// you build maps to one of them. (Recipe 1: start from the question.)
const EXEC_QUESTIONS = [
  "Where is the biggest pain point in the Starbucks customer experience?",
  "TODO: write your second question here",
  "TODO: write your third question here",
]

function App() {
  const [reviews, setReviews] = useState<Review[] | null>(null)
  const [codebook, setCodebook] = useState<Codebook | null>(null)

  // FILTERS — currently only stars. The exercise extends this to city + theme.
  // TODO #4: add `cities: string[]` and `themes: string[]` to the filter state,
  // then surface them as chips in the filter row below.
  const [selectedStars, setSelectedStars] = useState<number[]>([])

  useEffect(() => {
    Promise.all([loadReviews(), loadCodebook()]).then(([r, c]) => {
      setReviews(r)
      setCodebook(c)
    })
  }, [])

  const filtered = useMemo(() => {
    if (!reviews) return []
    return reviews.filter((r) => {
      if (selectedStars.length > 0 && !selectedStars.includes(r.stars)) {
        return false
      }
      return true
    })
  }, [reviews, selectedStars])

  if (!reviews || !codebook) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-bean-700 text-sm">Loading reviews and codebook...</p>
      </div>
    )
  }

  const toggleStar = (s: number) => {
    setSelectedStars((current) =>
      current.includes(s) ? current.filter((x) => x !== s) : [...current, s]
    )
  }

  return (
    <div className="min-h-screen">
      <header className="bg-cream-100 border-b border-cream-200 px-6 py-5">
        <h1 className="text-xl font-medium text-bean-900">
          Starbucks UXR · Your Portfolio Piece
        </h1>
        <p className="text-xs text-bean-700 mt-0.5">
          AI Kitchen starter template · {reviews.length.toLocaleString()} reviews
          loaded
        </p>
      </header>

      {/* The three exec questions. TODO #1: edit EXEC_QUESTIONS above. */}
      <section className="bg-cream-50 border-b border-cream-200 px-6 py-4">
        <p className="text-xs uppercase tracking-wide text-bean-700 mb-2">
          The questions this dashboard exists to answer
        </p>
        <ul className="space-y-1 text-sm text-bean-900">
          {EXEC_QUESTIONS.map((q, i) => (
            <li key={i} className="leading-snug">
              <span className="text-forest-600 font-mono mr-2">Q{i + 1}.</span>
              {q}
            </li>
          ))}
        </ul>
      </section>

      {/* FILTER PANEL. Today: stars only. TODO #4: add city and theme filters. */}
      <section className="bg-white border-b border-cream-200 px-6 py-3">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-xs uppercase tracking-wide text-bean-700">
            Stars
          </span>
          {[1, 2, 3, 4, 5].map((s) => (
            <button
              key={s}
              onClick={() => toggleStar(s)}
              className={`text-xs px-2.5 py-1 rounded-full border cursor-pointer ${
                selectedStars.includes(s)
                  ? "bg-forest-600 text-cream-50 border-forest-600"
                  : "bg-cream-50 text-bean-800 border-cream-200 hover:border-forest-500"
              }`}
            >
              {s}★
            </button>
          ))}
          {/* TODO #4: add city chips here, then theme chips. */}
        </div>
      </section>

      <main className="px-6 py-6 max-w-7xl mx-auto">
        <p className="text-sm text-bean-700 mb-4">
          <span className="font-mono text-bean-900 font-medium">
            {filtered.length}
          </span>{" "}
          of {reviews.length} reviews match your filters
        </p>

        {/* CHART GRID. Today: one chart. TODO #4: add two more, each answering
            a different exec question (Recipe 4: the dashboard is a question
            machine). */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <article className="bg-white border border-cream-200 rounded-lg p-5 shadow-sm">
            <header className="mb-3">
              <h3 className="text-sm font-medium text-bean-900">
                Theme prevalence
              </h3>
              <p className="text-xs text-bean-700 italic mt-1">
                "What are customers actually talking about?"
              </p>
            </header>
            <ThemeFrequencyChart reviews={filtered} codebook={codebook} />
          </article>

          {/* TODO #4: add a chart that answers exec question 2. Use the
              `ThemeFrequencyChart` as a starting point — copy it into a new
              file, change the aggregation logic, and adjust the props.

              Suggested follow-on charts:
              - Top complaints in 1-2 star reviews
              - Star distribution per theme (stacked bar)
              - Theme prevalence by city (grouped bar) */}

          <article className="bg-white border-2 border-dashed border-cream-200 rounded-lg p-5 flex items-center justify-center min-h-72">
            <p className="text-bean-700 italic text-center text-sm">
              <span className="text-forest-600 font-mono block mb-2">
                TODO #4
              </span>
              Add a second chart that answers exec question 2.
              <br />
              Prompt template in <code>materials/starter-prompts.md</code>.
            </p>
          </article>
        </div>

        {/* QUOTE PANEL. TODO #5: build this. Recipe 3 (cite or it didn't
            happen) is what makes your insights portfolio-defensible.
            Map over `filtered`, then over each review's
            `themes_with_quotes`, and render the verbatim quote with stars +
            city. */}
        <section className="mt-8 bg-white border-2 border-dashed border-cream-200 rounded-lg p-5 min-h-32 flex items-center justify-center">
          <p className="text-bean-700 italic text-sm text-center">
            <span className="text-forest-600 font-mono block mb-2">TODO #5</span>
            Add a Quote panel that grounds every claim in verbatim quotes from
            the reviews. Recipe 3 in action.
          </p>
        </section>
      </main>

      <footer className="border-t border-cream-200 mt-12 py-6 text-center text-xs text-bean-700">
        Starter template · extend me into your portfolio piece · AI Kitchen May
        22, 2026
      </footer>
    </div>
  )
}

export default App

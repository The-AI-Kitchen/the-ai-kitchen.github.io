import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import type { Codebook, Review } from "../types"

interface Props {
  reviews: Review[]
  codebook: Codebook
}

export function ThemeFrequencyChart({ reviews, codebook }: Props) {
  const counts = new Map<string, number>()
  for (const r of reviews) {
    for (const t of r.themes) {
      counts.set(t, (counts.get(t) ?? 0) + 1)
    }
  }
  const data = codebook.themes
    .map((t) => ({
      theme_name: t.name,
      count: counts.get(t.id) ?? 0,
    }))
    .filter((d) => d.count > 0)
    .sort((a, b) => b.count - a.count)

  if (data.length === 0) {
    return (
      <p className="text-bean-700 italic text-sm">No reviews match the filter.</p>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart
        data={data}
        layout="vertical"
        margin={{ top: 5, right: 20, left: 80, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#ebe4d3" horizontal={false} />
        <XAxis type="number" stroke="#3e2c20" fontSize={11} />
        <YAxis
          type="category"
          dataKey="theme_name"
          stroke="#3e2c20"
          fontSize={11}
          width={140}
        />
        <Tooltip
          contentStyle={{
            background: "#fbf9f4",
            border: "1px solid #ebe4d3",
            borderRadius: 6,
            fontSize: 12,
          }}
        />
        <Bar dataKey="count" fill="#2f6b5a" radius={[0, 4, 4, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}

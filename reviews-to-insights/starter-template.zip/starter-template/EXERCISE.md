# The exercise (50 minutes)

Four tasks in order, plus an optional stretch goal. You'll need Cursor Pro and Claude Pro open. The prompts you'll use are in `../materials/starter-prompts.md`.

---

## Task 1 — Write three exec questions (5 min)

Open `src/App.tsx`. Find `EXEC_QUESTIONS`. Replace the placeholders with three questions you would actually ask if you were the Starbucks VP of Research.

**Recipe 1**: Every chart you build today maps to one of these three questions. If a chart doesn't, cut it.

Good question shapes to steal:
- "Where is X getting worse, and is it concentrated by [city / time / channel]?"
- "Among our happiest customers, what's the most common complaint?"
- "Which channel has the worst service-quality variance?"

---

## Task 2 — Extend the codebook (10 min)

Open `public/starbucks_codebook.json`. Read 20-30 reviews from one city (use the dashboard's stars filter, or open the CSV directly).

Propose **one new theme** the starter codebook is missing. Add it to the JSON in the same shape as the existing themes:

```json
{
  "id": "your_theme_id",
  "name": "Display Name",
  "definition": "1-2 sentences. Distinguish it from other themes.",
  "examples": ["verbatim phrase from a review", "another verbatim phrase"],
  "business_question": "which corporate decision-maker cares and what do they want to know"
}
```

Use **Prompt 1** in `../materials/starter-prompts.md` if you want AI help drafting it.

**Recipe 2** in action: you're updating the codebook, not the AI's opinion.

---

## Task 3 — Add two more charts (25 min)

In `src/App.tsx`, find `TODO #4`. Right now there's one chart and a placeholder slot. Add two more charts, each answering a different exec question from Task 1.

Easy starting point: copy `src/components/ThemeFrequencyChart.tsx` into a new file, change the aggregation logic, change the title.

Chart ideas:
- **Top complaints in 1-2 star reviews** — filter to low stars, run the same theme count
- **Star distribution per theme** — stacked bar showing 1-5 star breakdown per theme
- **Theme prevalence by city** — grouped bar showing % share of each theme by city

Use **Prompt 3** in `../materials/starter-prompts.md` if you want Cursor to write the chart for you.

**Recipe 4** in action: each chart answers one named question.

---

## Task 4 — Quote panel + memo (10 min)

### 4a (5 min): Quote Panel
Find `TODO #5` in `src/App.tsx`. Replace the placeholder with a component that displays grounding quotes from the reviews. The shape: for each review, walk `themes_with_quotes` and render the verbatim quote with the theme name, stars, and city.

Why this matters: at 4:10 PM you'll defend your work against a VP. When they say "really? show me," you point at the panel.

### 4b (5 min): Insight Memo
Open `../materials/insight-memo-template.md`. Fill in three insights. Each must cite at least one verbatim quote from your data. Aim for one page. Don't worry about polish — get the bones down.

**Recipes 1+3** in action: insights pointed at named decisions, grounded in verifiable quotes.

---

## Stretch goal — Re-code 100 reviews against your extended codebook

Open Cursor agent mode in this project. Paste **Prompt 2** from `../materials/starter-prompts.md`. It will apply your updated codebook (including your new theme) to 100 reviews and write the output to a new file.

Check the count of reviews tagged with your new theme. If it's zero, either your theme is too narrow, your definition is too strict, or you picked a topic the data doesn't really contain. Iterate.

---

## The killer move for the live Q&A

**Make your dashboard queryable beyond what you've charted.** In Cursor agent mode, ask plain-English questions of `public/starbucks_reviews_coded.csv`. Try:

> "What % of 1-star reviews from Reno mention the drive-thru?"

This is Recipe 4 in its strongest form: when the VP asks something your dashboard can't directly chart, switch to Cursor agent and answer live. Practice this once or twice before 4:10 — it's the move that separates great portfolios from good ones.

---

## If you only have time for one thing

Write three great exec questions. Build one chart that answers one of them. Write one grounded insight bullet. That's enough to defend something interesting at the live Q&A.

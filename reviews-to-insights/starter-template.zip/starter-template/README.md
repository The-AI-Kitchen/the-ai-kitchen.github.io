# Starbucks UXR Starter Template

You are starting your AI Kitchen portfolio piece here. By 4:30 PM you'll have a draft dashboard plus a one-page insight memo.

## Setup (5 min)

```bash
npm install
npm run dev
```

Open http://localhost:5173. You should see one chart (theme prevalence) and a stars filter.

## The exercise

Read [EXERCISE.md](./EXERCISE.md) for the five tasks, in order. Use the prompts in `../materials/starter-prompts.md` to vibe-code your way through.

When the dashboard works the way you want, write your insight memo using `../materials/insight-memo-template.md`.

## What's here vs. what you build

```
src/
  App.tsx                          # the shell. has TODOs #1, #4, #5 marked.
  types.ts                         # Review, Theme, Codebook — don't need to edit.
  data/loadData.ts                 # CSV + JSON loaders — don't need to edit.
  components/
    ThemeFrequencyChart.tsx        # ONE working chart. copy this to add more.
public/
  starbucks_reviews_coded.csv      # data you analyze. add reviews / re-code if you extend the codebook.
  starbucks_codebook.json          # codebook. TASK 2: extend this with one new theme.
```

## Tips

- Have Cursor open in this directory. Use agent mode for any "how do I..." question.
- The four recipes are your scoring rubric. The exec Q&A at 3:50 PM is graded against them.
- If you only have time for one task: pick a great exec question, build a chart that answers it, write three grounded insights. That's enough for a defensible portfolio piece.

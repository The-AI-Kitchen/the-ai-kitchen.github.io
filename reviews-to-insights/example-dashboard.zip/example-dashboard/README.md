# Example dashboard

The finished Starbucks UXR dashboard that Zach demos live during the AI Kitchen session on May 22. Vite + React + TypeScript + Tailwind v4 + recharts. Runs entirely on localhost, no deployment.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:5173.

## Data

The dashboard reads two files from `public/`:

- `starbucks_reviews_coded.csv` — every review tagged with up to 3 themes plus the verbatim quote that grounds each theme assignment.
- `starbucks_codebook.json` — the codebook used during coding (themes + definitions + business questions).

Today these are small sample files (30 reviews) so the dashboard renders before the real data pipeline runs. Once `../scripts/01_curate_starbucks.py` and `../scripts/02_run_thematic_coding.py` have run, swap in the real files:

```bash
cp ../data/starbucks_reviews_coded.csv public/starbucks_reviews_coded.csv
cp ../data/starbucks_codebook_starter.json public/starbucks_codebook.json
```

No code changes needed; the schema is the same.

## How the four recipes show up in the UI

- **Recipe 1 (question first)** — three exec questions are visible at the top, every chart card cites the question it answers.
- **Recipe 2 (codebook over vibes)** — the codebook is loaded from `public/starbucks_codebook.json`. Every theme in the filters comes from there, with the definition as a hover tooltip.
- **Recipe 3 (cite or it didn't happen)** — the Quote List panel pulls verbatim quotes from `themes_with_quotes_json`. Clicking a theme bar focuses the panel on that theme.
- **Recipe 4 (question machine)** — filters are framed as "the follow-up questions the exec will ask," and the CursorHint panel explains the fallback workflow for questions the dashboard doesn't directly answer.

## Project structure

```
src/
  App.tsx                      # layout shell, filter state, data loading
  types.ts                     # Review, Theme, Codebook, Filters
  data/
    loadData.ts                # CSV + JSON fetchers
    aggregations.ts            # countByTheme, shareByThemeAndCity, etc.
  components/
    Header.tsx
    QuestionStrip.tsx          # the three exec questions
    FilterPanel.tsx            # stars / cities / themes
    ChartCard.tsx              # standard chart wrapper with title + question + recipe tag
    QuoteList.tsx              # grounding quotes for current filter context
    CursorHint.tsx             # Recipe 4 panel showing the Cursor agent fallback
    charts/
      ThemeFrequencyChart.tsx
      StarsByThemeChart.tsx
      ThemeByCityChart.tsx
      TopComplaintsChart.tsx
public/
  starbucks_reviews_coded.csv  # sample data; replaced by pipeline output
  starbucks_codebook.json      # sample codebook; replaced by pipeline output
```

## Notes for extending during the live demo

- Add a chart: drop a new file in `src/components/charts/`, write an aggregator in `src/data/aggregations.ts` if needed, then wire it into `App.tsx`.
- Add a filter: extend `Filters` in `types.ts`, update `FilterPanel.tsx`, and apply it in `applyFilters` inside `App.tsx`.
- Add interactivity (e.g., click-to-focus on the city chart): pass an `onSelect` callback to the chart component the same way `ThemeFrequencyChart` does.

import { useEffect, useMemo, useState } from "react"
import { Header } from "./components/Header"
import { QuestionStrip } from "./components/QuestionStrip"
import { FilterPanel } from "./components/FilterPanel"
import { ChartCard } from "./components/ChartCard"
import { ThemeFrequencyChart } from "./components/charts/ThemeFrequencyChart"
import { StarsByThemeChart } from "./components/charts/StarsByThemeChart"
import { ThemeByCityChart } from "./components/charts/ThemeByCityChart"
import { TopComplaintsChart } from "./components/charts/TopComplaintsChart"
import { QuoteList } from "./components/QuoteList"
import { CursorHint } from "./components/CursorHint"
import type { Codebook, Filters, Review } from "./types"
import { EMPTY_FILTERS } from "./types"
import { loadCodebook, loadReviews } from "./data/loadData"

function applyFilters(reviews: Review[], filters: Filters): Review[] {
  return reviews.filter((r) => {
    if (filters.cities.length > 0 && !filters.cities.includes(r.city)) return false
    if (filters.stars.length > 0 && !filters.stars.includes(r.stars)) return false
    if (filters.themes.length > 0) {
      const hit = r.themes.some((t) => filters.themes.includes(t))
      if (!hit) return false
    }
    return true
  })
}

function App() {
  const [reviews, setReviews] = useState<Review[] | null>(null)
  const [codebook, setCodebook] = useState<Codebook | null>(null)
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS)
  const [focusTheme, setFocusTheme] = useState<string | null>(null)
  const [loadError, setLoadError] = useState<string | null>(null)

  useEffect(() => {
    Promise.all([loadReviews(), loadCodebook()])
      .then(([r, c]) => {
        setReviews(r)
        setCodebook(c)
      })
      .catch((err) => {
        console.error(err)
        setLoadError(err.message)
      })
  }, [])

  const { topCities, cityCount } = useMemo(() => {
    if (!reviews) return { topCities: [] as string[], cityCount: 0 }
    const counts = new Map<string, number>()
    for (const r of reviews) {
      if (!r.city) continue
      counts.set(r.city, (counts.get(r.city) ?? 0) + 1)
    }
    const ranked = Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([city]) => city)
    return { topCities: ranked.slice(0, 20), cityCount: counts.size }
  }, [reviews])

  const filtered = useMemo(() => {
    if (!reviews) return []
    return applyFilters(reviews, filters)
  }, [reviews, filters])

  const dateRange = useMemo(() => {
    if (!reviews || reviews.length === 0) return "—"
    const dates = reviews.map((r) => r.date).filter(Boolean).sort()
    if (dates.length === 0) return "—"
    const first = dates[0].slice(0, 4)
    const last = dates[dates.length - 1].slice(0, 4)
    return first === last ? first : `${first}-${last}`
  }, [reviews])

  const businessCount = useMemo(() => {
    if (!reviews) return 0
    return new Set(reviews.map((r) => r.business_id)).size
  }, [reviews])

  if (loadError) {
    return <LoadError message={loadError} />
  }
  if (!reviews || !codebook) {
    return <Loading />
  }

  return (
    <div className="min-h-screen">
      <Header
        reviewCount={reviews.length}
        businessCount={businessCount}
        cityCount={cityCount}
        dateRange={dateRange}
      />
      <QuestionStrip />
      <FilterPanel
        filters={filters}
        setFilters={setFilters}
        cities={topCities}
        cityCount={cityCount}
        codebook={codebook}
      />

      <main className="mx-auto max-w-7xl px-6 py-6">
        <div className="mb-3 flex items-baseline justify-between">
          <p className="text-sm text-bean-700">
            <span className="font-mono text-bean-900 font-medium">
              {filtered.length.toLocaleString()}
            </span>{" "}
            of {reviews.length.toLocaleString()} reviews match your filters
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <ChartCard
            title="Theme prevalence"
            question="What are customers actually talking about?"
            recipe="Recipe 2 · codebook over vibes"
          >
            <ThemeFrequencyChart
              reviews={filtered}
              codebook={codebook}
              onSelectTheme={(t) =>
                setFocusTheme((current) => (current === t ? null : t))
              }
            />
          </ChartCard>

          <ChartCard
            title="Top complaints in 1-2 star reviews"
            question="Which themes drive the worst experiences?"
            recipe="Recipe 1 · question first"
          >
            <TopComplaintsChart reviews={filtered} codebook={codebook} />
          </ChartCard>

          <ChartCard
            title="Star distribution by theme"
            question="Which themes are praise vs. complaint?"
            recipe="Recipe 4 · question machine"
          >
            <StarsByThemeChart reviews={filtered} codebook={codebook} />
          </ChartCard>

          <ChartCard
            title="Theme prevalence by city (%)"
            question="Is this a national pattern or a local one?"
            recipe="Recipe 4 · question machine"
          >
            <ThemeByCityChart reviews={filtered} codebook={codebook} />
          </ChartCard>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mt-5">
          <QuoteList
            reviews={filtered}
            codebook={codebook}
            focusTheme={focusTheme}
            setFocusTheme={setFocusTheme}
          />
          <CursorHint />
        </div>
      </main>

      <footer className="border-t border-cream-200 mt-12 py-6 text-center text-xs text-bean-700">
        Built with the four recipes from{" "}
        <a
          href="https://theaikitchen.org/"
          className="underline hover:text-forest-600"
          target="_blank"
          rel="noreferrer"
        >
          AI Kitchen
        </a>
        {" "}at Santa Clara University · May 2026
      </footer>
    </div>
  )
}

function Loading() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-cream-50">
      <p className="text-bean-700 text-sm">Loading reviews and codebook...</p>
    </div>
  )
}

function LoadError({ message }: { message: string }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-cream-50 px-6">
      <div className="max-w-lg bg-white border border-cream-200 rounded-lg p-6 shadow-sm">
        <h2 className="text-lg font-medium text-bean-900 mb-2">
          Couldn't load the data
        </h2>
        <p className="text-sm text-bean-700 mb-3">{message}</p>
        <p className="text-sm text-bean-700">
          Expected files in <code>public/</code>:
        </p>
        <ul className="text-sm text-bean-700 list-disc pl-5 mt-1">
          <li>
            <code>starbucks_reviews_coded.csv</code>
          </li>
          <li>
            <code>starbucks_codebook.json</code>
          </li>
        </ul>
        <p className="text-sm text-bean-700 mt-3">
          Run the data pipeline in <code>scripts/</code> to produce them, or
          keep the sample files in place while developing.
        </p>
      </div>
    </div>
  )
}

export default App

import { X } from "lucide-react"
import type { Codebook, Filters } from "../types"

interface FilterPanelProps {
  filters: Filters
  setFilters: (f: Filters) => void
  cities: string[]
  cityCount?: number
  codebook: Codebook
}

export function FilterPanel({
  filters,
  setFilters,
  cities,
  cityCount,
  codebook,
}: FilterPanelProps) {
  // Show top-N cities plus any active filter not already in the list,
  // so a selection from Cursor agent mode stays visible.
  const visibleCities = Array.from(new Set([...cities, ...filters.cities]))
  const stars = [1, 2, 3, 4, 5]

  const toggle = (
    key: "cities" | "stars" | "themes",
    value: string | number
  ) => {
    const current = filters[key] as Array<typeof value>
    const exists = current.includes(value)
    const next = exists
      ? current.filter((v) => v !== value)
      : [...current, value]
    setFilters({ ...filters, [key]: next })
  }

  const reset = () =>
    setFilters({ cities: [], stars: [], themes: [] })

  const hasFilters =
    filters.cities.length > 0 ||
    filters.stars.length > 0 ||
    filters.themes.length > 0

  return (
    <section className="border-b border-cream-200 bg-white">
      <div className="mx-auto max-w-7xl px-6 py-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-medium uppercase tracking-wide text-bean-700">
            Filters
          </h3>
          {hasFilters && (
            <button
              onClick={reset}
              className="text-xs text-bean-700 hover:text-bean-900 flex items-center gap-1 cursor-pointer"
            >
              <X className="w-3 h-3" /> reset
            </button>
          )}
        </div>

        <FilterGroup label="Stars">
          {stars.map((s) => (
            <Chip
              key={s}
              active={filters.stars.includes(s)}
              onClick={() => toggle("stars", s)}
            >
              {s}★
            </Chip>
          ))}
        </FilterGroup>

        <FilterGroup label="City">
          {visibleCities.map((c) => (
            <Chip
              key={c}
              active={filters.cities.includes(c)}
              onClick={() => toggle("cities", c)}
            >
              {c}
            </Chip>
          ))}
          {cityCount && cityCount > cities.length ? (
            <span className="text-[11px] text-bean-700 italic ml-1">
              top {cities.length} of {cityCount} · ask Cursor for any other city
            </span>
          ) : null}
        </FilterGroup>

        <FilterGroup label="Theme">
          {codebook.themes.map((t) => (
            <Chip
              key={t.id}
              active={filters.themes.includes(t.id)}
              onClick={() => toggle("themes", t.id)}
              title={t.definition}
            >
              {t.name}
            </Chip>
          ))}
        </FilterGroup>
      </div>
    </section>
  )
}

function FilterGroup({
  label,
  children,
}: {
  label: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-xs uppercase tracking-wide text-bean-700 min-w-16">
        {label}
      </span>
      <div className="flex flex-wrap gap-1.5">{children}</div>
    </div>
  )
}

function Chip({
  active,
  onClick,
  children,
  title,
}: {
  active: boolean
  onClick: () => void
  children: React.ReactNode
  title?: string
}) {
  const base = "text-xs px-2.5 py-1 rounded-full border transition cursor-pointer"
  const activeCls = "bg-forest-600 text-cream-50 border-forest-600"
  const inactiveCls =
    "bg-cream-50 text-bean-800 border-cream-200 hover:border-forest-500"
  return (
    <button
      onClick={onClick}
      title={title}
      className={`${base} ${active ? activeCls : inactiveCls}`}
    >
      {children}
    </button>
  )
}

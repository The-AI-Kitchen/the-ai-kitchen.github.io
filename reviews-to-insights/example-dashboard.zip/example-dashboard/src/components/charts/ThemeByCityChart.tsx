import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import type { Codebook, Review } from "../../types"
import { countByTheme, shareByThemeAndCity } from "../../data/aggregations"

interface Props {
  reviews: Review[]
  codebook: Codebook
}

const COLORS = ["#2f6b5a", "#b87333", "#b34a4a", "#3e2c20", "#6b9e7c"]

export function ThemeByCityChart({ reviews, codebook }: Props) {
  const topThemes = countByTheme(reviews, codebook)
    .filter((t) => t.count > 0)
    .slice(0, 4)

  if (topThemes.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-bean-700 text-sm italic">
        No reviews match the current filters.
      </div>
    )
  }

  const rows = shareByThemeAndCity(
    reviews,
    topThemes.map((t) => t.theme_id)
  )

  const chartData = rows.map((row) => {
    const r: Record<string, string | number> = { city: row.city }
    for (const t of topThemes) {
      r[t.theme_name] = Math.round(row.shareByTheme[t.theme_id] * 100)
    }
    return r
  })

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={chartData}
        margin={{ top: 5, right: 10, left: 0, bottom: 50 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#ebe4d3" />
        <XAxis
          dataKey="city"
          stroke="#3e2c20"
          fontSize={11}
          angle={-30}
          textAnchor="end"
          height={60}
        />
        <YAxis
          stroke="#3e2c20"
          fontSize={11}
          tickFormatter={(v) => `${v}%`}
        />
        <Tooltip
          contentStyle={{
            background: "#fbf9f4",
            border: "1px solid #ebe4d3",
            borderRadius: 6,
            fontSize: 12,
          }}
          formatter={(value) => `${value}%`}
        />
        <Legend wrapperStyle={{ fontSize: 10 }} />
        {topThemes.map((t, i) => (
          <Bar
            key={t.theme_id}
            dataKey={t.theme_name}
            fill={COLORS[i % COLORS.length]}
            radius={[3, 3, 0, 0]}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  )
}

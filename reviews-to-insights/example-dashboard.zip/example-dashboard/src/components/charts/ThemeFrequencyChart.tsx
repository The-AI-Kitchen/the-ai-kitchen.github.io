import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import type { Codebook, Review } from "../../types"
import { countByTheme } from "../../data/aggregations"

interface Props {
  reviews: Review[]
  codebook: Codebook
  onSelectTheme?: (themeId: string) => void
}

export function ThemeFrequencyChart({ reviews, codebook, onSelectTheme }: Props) {
  const data = countByTheme(reviews, codebook).filter((d) => d.count > 0)

  if (data.length === 0) {
    return <EmptyState />
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        layout="vertical"
        margin={{ top: 5, right: 20, left: 80, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#ebe4d3" horizontal={false} />
        <XAxis type="number" stroke="#3e2c20" fontSize={11} />
        <YAxis
          type="category"
          dataKey="theme_name"
          stroke="#3e2c20"
          fontSize={11}
          width={140}
          interval={0}
        />
        <Tooltip
          cursor={{ fill: "rgba(47, 107, 90, 0.08)" }}
          contentStyle={{
            background: "#fbf9f4",
            border: "1px solid #ebe4d3",
            borderRadius: 6,
            fontSize: 12,
          }}
        />
        <Bar
          dataKey="count"
          fill="#2f6b5a"
          radius={[0, 4, 4, 0]}
          onClick={(d) => onSelectTheme?.((d as unknown as { theme_id: string }).theme_id)}
          cursor="pointer"
        />
      </BarChart>
    </ResponsiveContainer>
  )
}

function EmptyState() {
  return (
    <div className="h-full flex items-center justify-center text-bean-700 text-sm italic">
      No reviews match the current filters.
    </div>
  )
}

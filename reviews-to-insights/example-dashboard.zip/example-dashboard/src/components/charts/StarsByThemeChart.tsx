import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import type { Codebook, Review } from "../../types"
import { countByThemeAndStars } from "../../data/aggregations"

interface Props {
  reviews: Review[]
  codebook: Codebook
}

const STAR_COLORS: Record<string, string> = {
  "1": "#b34a4a",
  "2": "#d97954",
  "3": "#c9a352",
  "4": "#6b9e7c",
  "5": "#2f6b5a",
}

export function StarsByThemeChart({ reviews, codebook }: Props) {
  const data = countByThemeAndStars(reviews, codebook).filter(
    (d) => d["1"] + d["2"] + d["3"] + d["4"] + d["5"] > 0
  )

  if (data.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-bean-700 text-sm italic">
        No reviews match the current filters.
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{ top: 5, right: 10, left: 0, bottom: 60 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#ebe4d3" />
        <XAxis
          dataKey="theme_name"
          stroke="#3e2c20"
          fontSize={10}
          angle={-35}
          textAnchor="end"
          interval={0}
          height={70}
        />
        <YAxis stroke="#3e2c20" fontSize={11} />
        <Tooltip
          contentStyle={{
            background: "#fbf9f4",
            border: "1px solid #ebe4d3",
            borderRadius: 6,
            fontSize: 12,
          }}
        />
        <Legend wrapperStyle={{ fontSize: 11 }} />
        {(["1", "2", "3", "4", "5"] as const).map((star) => (
          <Bar
            key={star}
            dataKey={star}
            stackId="stars"
            fill={STAR_COLORS[star]}
            name={`${star} star`}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  )
}

import { Terminal } from "lucide-react"

export function CursorHint() {
  return (
    <aside className="bg-bean-900 text-cream-100 border border-bean-800 rounded-lg p-5 shadow-sm">
      <header className="flex items-center gap-2 mb-3">
        <Terminal className="w-4 h-4 text-amber-accent" />
        <h3 className="text-sm font-medium text-cream-50">
          Recipe 4 · the dashboard is a question machine
        </h3>
      </header>
      <p className="text-sm leading-relaxed text-cream-100 mb-3">
        When the exec asks something this dashboard can't directly answer,
        switch to Cursor agent mode in this project and ask in plain English.
        Cursor will read the CSV, run Python, and answer with a chart or number.
      </p>
      <div className="bg-bean-800 border border-bean-700 rounded p-3 font-mono text-xs text-cream-100 leading-relaxed">
        <span className="text-amber-accent">cursor</span> · agent mode · in this
        project:
        <div className="mt-2 text-cream-50">
          "What percent of 1-star reviews from Philadelphia mention the mobile
          app? Compare to Tampa."
        </div>
      </div>
    </aside>
  )
}

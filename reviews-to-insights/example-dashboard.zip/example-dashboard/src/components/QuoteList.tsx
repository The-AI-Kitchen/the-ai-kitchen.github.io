import { Quote } from "lucide-react"
import type { Codebook, Review } from "../types"

interface QuoteListProps {
  reviews: Review[]
  codebook: Codebook
  focusTheme: string | null
  setFocusTheme: (id: string | null) => void
}

export function QuoteList({
  reviews,
  codebook,
  focusTheme,
  setFocusTheme,
}: QuoteListProps) {
  const themeLookup = new Map(codebook.themes.map((t) => [t.id, t.name]))
  const focusName = focusTheme ? themeLookup.get(focusTheme) ?? focusTheme : null

  const quotes: Array<{
    review_id: string
    quote: string
    theme_id: string
    theme_name: string
    stars: number
    city: string
    state: string
  }> = []
  for (const r of reviews) {
    for (const t of r.themes_with_quotes) {
      if (focusTheme && t.theme_id !== focusTheme) continue
      quotes.push({
        review_id: r.review_id,
        quote: t.quote,
        theme_id: t.theme_id,
        theme_name: themeLookup.get(t.theme_id) ?? t.theme_id,
        stars: r.stars,
        city: r.city,
        state: r.state,
      })
    }
  }

  const display = quotes.slice(0, 8)

  return (
    <section className="bg-white border border-cream-200 rounded-lg p-5 shadow-sm">
      <header className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Quote className="w-4 h-4 text-forest-600" />
          <h3 className="text-sm font-medium text-bean-900">
            Grounding quotes
            {focusName && (
              <span className="text-bean-700 font-normal">
                {" "}
                · {focusName}
              </span>
            )}
          </h3>
        </div>
        {focusTheme && (
          <button
            onClick={() => setFocusTheme(null)}
            className="text-xs text-bean-700 hover:text-bean-900 cursor-pointer"
          >
            clear focus
          </button>
        )}
      </header>
      <p className="text-xs text-bean-700 italic mb-4">
        Recipe 3: every theme assignment cites a verbatim span from a real review.
        Click a bar in any chart to focus the quotes on that theme.
      </p>
      {display.length === 0 ? (
        <p className="text-sm text-bean-700 italic">No quotes for this slice.</p>
      ) : (
        <ul className="space-y-3">
          {display.map((q, i) => (
            <li
              key={`${q.review_id}-${i}`}
              className="border-l-2 border-forest-500 pl-3 py-1"
            >
              <p className="text-sm text-bean-900 leading-snug">
                "{q.quote}"
              </p>
              <p className="text-[10px] text-bean-700 mt-1 uppercase tracking-wide">
                {q.theme_name} · {q.stars}★ · {q.city}, {q.state}
              </p>
            </li>
          ))}
        </ul>
      )}
      {quotes.length > display.length && (
        <p className="text-xs text-bean-700 mt-3 italic">
          Showing {display.length} of {quotes.length} matching quotes.
        </p>
      )}
    </section>
  )
}

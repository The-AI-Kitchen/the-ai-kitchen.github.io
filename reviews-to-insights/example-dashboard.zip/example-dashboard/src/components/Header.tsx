import { Coffee } from "lucide-react"

interface HeaderProps {
  reviewCount: number
  businessCount: number
  cityCount: number
  dateRange: string
}

export function Header({
  reviewCount,
  businessCount,
  cityCount,
  dateRange,
}: HeaderProps) {
  return (
    <header className="border-b border-cream-200 bg-cream-100">
      <div className="mx-auto max-w-7xl px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-forest-600 flex items-center justify-center">
            <Coffee className="w-5 h-5 text-cream-50" />
          </div>
          <div>
            <h1 className="text-xl font-medium text-bean-900 leading-tight">
              Starbucks UXR · Yelp Review Dashboard
            </h1>
            <p className="text-xs text-bean-700 mt-0.5">
              A portfolio piece by Zach Schendel · AI Kitchen at SCU · May 22, 2026
            </p>
          </div>
        </div>
        <div className="hidden md:flex gap-6 text-xs">
          <Stat label="reviews coded" value={reviewCount.toLocaleString()} />
          <Stat label="locations" value={businessCount.toLocaleString()} />
          <Stat label="cities" value={cityCount.toLocaleString()} />
          <Stat label="date range" value={dateRange} />
        </div>
      </div>
    </header>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col items-end">
      <span className="font-mono text-bean-900 font-medium">{value}</span>
      <span className="text-bean-700 uppercase tracking-wide">{label}</span>
    </div>
  )
}

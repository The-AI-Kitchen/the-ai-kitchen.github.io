interface ChartCardProps {
  title: string
  question: string
  recipe?: string
  children: React.ReactNode
}

export function ChartCard({ title, question, recipe, children }: ChartCardProps) {
  return (
    <article className="bg-white border border-cream-200 rounded-lg p-5 shadow-sm">
      <header className="mb-4">
        <h3 className="text-sm font-medium text-bean-900 leading-tight">
          {title}
        </h3>
        <p className="text-xs text-bean-700 mt-1 italic">"{question}"</p>
        {recipe && (
          <p className="text-[10px] uppercase tracking-wide text-forest-600 font-mono mt-1.5">
            {recipe}
          </p>
        )}
      </header>
      <div className="h-72">{children}</div>
    </article>
  )
}

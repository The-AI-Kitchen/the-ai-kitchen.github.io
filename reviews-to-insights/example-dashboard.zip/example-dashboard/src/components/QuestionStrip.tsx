import { HelpCircle } from "lucide-react"

const EXEC_QUESTIONS = [
  {
    owner: "VP Digital",
    text: "Is our mobile-order experience hurting in-store satisfaction, or helping it?",
  },
  {
    owner: "VP Store Design",
    text: "Where is the 'third place' promise eroding, and where is it still landing?",
  },
  {
    owner: "VP Customer Experience",
    text: "Which channel — drive-thru, in-store, mobile — has the worst service-quality variance?",
  },
]

export function QuestionStrip() {
  return (
    <section className="border-b border-cream-200 bg-cream-50">
      <div className="mx-auto max-w-7xl px-6 py-6">
        <div className="flex items-center gap-2 mb-3">
          <HelpCircle className="w-4 h-4 text-forest-600" />
          <h2 className="text-sm font-medium uppercase tracking-wide text-bean-700">
            The three executive questions this dashboard exists to answer
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {EXEC_QUESTIONS.map((q, i) => (
            <article
              key={i}
              className="bg-white border border-cream-200 rounded-lg p-4 shadow-sm"
            >
              <p className="text-xs uppercase tracking-wide text-forest-600 font-medium mb-1">
                {q.owner}
              </p>
              <p className="text-sm text-bean-900 leading-snug">{q.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

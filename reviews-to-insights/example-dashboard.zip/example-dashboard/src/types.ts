export interface ThemeAssignment {
  theme_id: string
  quote: string
  note?: string
}

export interface Review {
  review_id: string
  business_id: string
  business_name: string
  city: string
  state: string
  stars: number
  date: string
  text: string
  themes: string[]
  themes_with_quotes: ThemeAssignment[]
}

export interface Theme {
  id: string
  name: string
  definition: string
  examples: string[]
  business_question: string
}

export interface Codebook {
  name: string
  version: string
  intent: string
  themes: Theme[]
  extension_prompt?: string
}

export interface Filters {
  cities: string[]
  stars: number[]
  themes: string[]
}

export const EMPTY_FILTERS: Filters = {
  cities: [],
  stars: [],
  themes: [],
}

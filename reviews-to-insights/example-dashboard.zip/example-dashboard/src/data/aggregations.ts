import type { Codebook, Review } from "../types"

export interface ThemeCount {
  theme_id: string
  theme_name: string
  count: number
}

export function countByTheme(
  reviews: Review[],
  codebook: Codebook
): ThemeCount[] {
  const counts = new Map<string, number>()
  for (const r of reviews) {
    for (const t of r.themes) {
      counts.set(t, (counts.get(t) ?? 0) + 1)
    }
  }
  return codebook.themes
    .map((t) => ({
      theme_id: t.id,
      theme_name: t.name,
      count: counts.get(t.id) ?? 0,
    }))
    .sort((a, b) => b.count - a.count)
}

export interface ThemeByStars {
  theme_id: string
  theme_name: string
  "1": number
  "2": number
  "3": number
  "4": number
  "5": number
}

export function countByThemeAndStars(
  reviews: Review[],
  codebook: Codebook
): ThemeByStars[] {
  const init = (): ThemeByStars["1" | "2" | "3" | "4" | "5"] => 0
  const counts = new Map<
    string,
    { "1": number; "2": number; "3": number; "4": number; "5": number }
  >()
  for (const t of codebook.themes) {
    counts.set(t.id, {
      "1": init(),
      "2": init(),
      "3": init(),
      "4": init(),
      "5": init(),
    })
  }
  for (const r of reviews) {
    const s = String(r.stars) as "1" | "2" | "3" | "4" | "5"
    for (const t of r.themes) {
      const c = counts.get(t)
      if (c) c[s] += 1
    }
  }
  return codebook.themes.map((t) => ({
    theme_id: t.id,
    theme_name: t.name,
    ...counts.get(t.id)!,
  }))
}

export interface ThemeShareByCity {
  city: string
  total: number
  shareByTheme: Record<string, number>
}

export function shareByThemeAndCity(
  reviews: Review[],
  topThemes: string[]
): ThemeShareByCity[] {
  const byCity = new Map<string, Review[]>()
  for (const r of reviews) {
    if (!r.city) continue
    if (!byCity.has(r.city)) byCity.set(r.city, [])
    byCity.get(r.city)!.push(r)
  }
  const rows: ThemeShareByCity[] = []
  for (const [city, list] of byCity.entries()) {
    if (list.length < 5) continue
    const shareByTheme: Record<string, number> = {}
    for (const themeId of topThemes) {
      const n = list.filter((r) => r.themes.includes(themeId)).length
      shareByTheme[themeId] = n / list.length
    }
    rows.push({ city, total: list.length, shareByTheme })
  }
  return rows.sort((a, b) => b.total - a.total)
}

export function topComplaintsInLowStars(
  reviews: Review[],
  codebook: Codebook,
  topN = 6
): ThemeCount[] {
  const lowStars = reviews.filter((r) => r.stars <= 2)
  return countByTheme(lowStars, codebook).slice(0, topN)
}

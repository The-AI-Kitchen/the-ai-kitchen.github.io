import Papa from "papaparse"
import type { Codebook, Review, ThemeAssignment } from "../types"

const REVIEWS_PATH = `${import.meta.env.BASE_URL}starbucks_reviews_coded.csv`
const CODEBOOK_PATH = `${import.meta.env.BASE_URL}starbucks_codebook.json`

interface RawReviewRow {
  review_id: string
  business_id: string
  business_name: string
  city: string
  state: string
  stars: string
  date: string
  text: string
  themes: string
  themes_with_quotes_json: string
}

function parseThemeJson(raw: string): ThemeAssignment[] {
  if (!raw || raw === "[]") return []
  try {
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    return parsed.filter(
      (t): t is ThemeAssignment =>
        typeof t === "object" &&
        t !== null &&
        typeof t.theme_id === "string" &&
        typeof t.quote === "string"
    )
  } catch {
    return []
  }
}

export async function loadReviews(): Promise<Review[]> {
  const response = await fetch(REVIEWS_PATH)
  if (!response.ok) {
    throw new Error(
      `Failed to load reviews at ${REVIEWS_PATH}. Did you run the data pipeline?`
    )
  }
  const csvText = await response.text()
  const parsed = Papa.parse<RawReviewRow>(csvText, {
    header: true,
    skipEmptyLines: true,
  })
  if (parsed.errors.length > 0) {
    console.warn("CSV parse warnings:", parsed.errors)
  }
  return parsed.data
    .filter((row) => row.review_id)
    .map((row) => ({
      review_id: row.review_id,
      business_id: row.business_id,
      business_name: row.business_name,
      city: row.city,
      state: row.state,
      stars: Number(row.stars),
      date: row.date,
      text: row.text,
      themes: row.themes ? row.themes.split("|").filter(Boolean) : [],
      themes_with_quotes: parseThemeJson(row.themes_with_quotes_json),
    }))
}

export async function loadCodebook(): Promise<Codebook> {
  const response = await fetch(CODEBOOK_PATH)
  if (!response.ok) {
    throw new Error(`Failed to load codebook at ${CODEBOOK_PATH}`)
  }
  return response.json()
}

const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");

// ============================================================
// SCU Brand Specs
// ============================================================
const C = {
  // Primary palette (from brand guidelines slide 22)
  scuRed:     "A32035",  // PMS 201 C
  broncoRed:  "862633",  // PMS 202 C
  stone:      "758592",  // PMS 7544 C
  white:      "FFFFFF",
  black:      "000000",
  // Tertiary/Neutral palette (slide 24)
  fog:        "E0DAD3",
  fogLight:   "EFECE9",
  adobe:      "F1E7CC",
  adobeLight: "F8F3E5",
  clay:       "C2A98B",
  slate:      "425766",
  slateDark:  "2A373F",
  slateLight: "D0D5D9",
  // Functional
  gold:       "FFB600",  // accent (from shield logo)
  bodyGray:   "555555",
  nearWhite:  "FAFAF7",
};

// SCU Brand Typography (slide 26-27):
//   Primary: Avenir Next  |  Secondary: Minion Pro
//   Free alternatives: Figtree (sans) + Crimson Pro (serif)
const FONT_H = "Figtree";      // Headers (free alt for Avenir Next)
const FONT_B = "Crimson Pro";   // Body (free alt for Minion Pro)

const W = 10;       // slide width (16:9)
const H = 5.625;    // slide height
const M = 0.5;      // standard margin

// Logo base64 for embedding
const logoColorPath = path.join(__dirname, "scu-logo-color.png");
const logoWhitePath = path.join(__dirname, "scu-logo-white.png");

const logoColorB64 = "image/png;base64," + fs.readFileSync(logoColorPath).toString("base64");
const logoWhiteB64 = "image/png;base64," + fs.readFileSync(logoWhitePath).toString("base64");

// ============================================================
// Helper: footer bar (appears on content slides)
// ============================================================
function addFooter(slide, leftText, rightText) {
  // Thin SCU Red line at bottom
  slide.addShape("rect", {
    x: 0, y: H - 0.35, w: W, h: 0.02,
    fill: { color: C.scuRed },
  });
  slide.addText(leftText, {
    x: M, y: H - 0.33, w: 4, h: 0.28,
    fontSize: 8, fontFace: FONT_B, color: C.stone, valign: "middle",
    margin: 0,
  });
  slide.addText(rightText, {
    x: W - M - 4, y: H - 0.33, w: 4, h: 0.28,
    fontSize: 8, fontFace: FONT_B, color: C.stone, align: "right", valign: "middle",
    margin: 0,
  });
}

function addLogoSmall(slide, variant) {
  const data = variant === "white" ? logoWhiteB64 : logoColorB64;
  // Logo in top-left, small
  slide.addImage({
    data,
    x: M, y: 0.2, w: 1.1, h: 0.36,
    sizing: { type: "contain", w: 1.1, h: 0.36 },
  });
}

// ============================================================
// BUILD
// ============================================================
const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.author = "Kai Lukoff";
pres.title  = "SCU Presentation Template";

// ────────────────────────────────────────────────────────────
// SLIDE 1: Title Slide (SCU Red background)
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.scuRed };

  // Bronco Red accent bar at top
  s.addShape("rect", {
    x: 0, y: 0, w: W, h: 0.06,
    fill: { color: C.broncoRed },
  });

  // White logo
  s.addImage({
    data: logoWhiteB64,
    x: M, y: 0.5, w: 1.6, h: 0.52,
    sizing: { type: "contain", w: 1.6, h: 0.52 },
  });

  // Title
  s.addText("Presentation Title", {
    x: M, y: 1.6, w: 7, h: 1.4,
    fontSize: 40, fontFace: FONT_H, color: C.white, bold: true,
    valign: "top", margin: 0,
  });

  // Subtitle
  s.addText("Subtitle or Course Name", {
    x: M, y: 3.0, w: 7, h: 0.5,
    fontSize: 16, fontFace: FONT_B, color: C.adobeLight, margin: 0,
  });

  // Gold accent line
  s.addShape("rect", {
    x: M, y: 3.65, w: 1.5, h: 0.04,
    fill: { color: C.gold },
  });

  // Presenter info
  s.addText("Presenter Name  |  Department  |  Date", {
    x: M, y: 3.85, w: 7, h: 0.4,
    fontSize: 12, fontFace: FONT_B, color: C.adobeLight, margin: 0,
  });

  // Bottom bronco red bar
  s.addShape("rect", {
    x: 0, y: H - 0.06, w: W, h: 0.06,
    fill: { color: C.broncoRed },
  });
}

// ────────────────────────────────────────────────────────────
// SLIDE 2: Today's Session / Agenda
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.nearWhite };
  addLogoSmall(s, "color");

  s.addText("Today's Session", {
    x: M, y: 0.7, w: 9, h: 0.7,
    fontSize: 32, fontFace: FONT_H, color: C.black, bold: true, margin: 0,
  });

  // Gold divider
  s.addShape("rect", {
    x: M, y: 1.45, w: 1.2, h: 0.04,
    fill: { color: C.gold },
  });

  // Agenda items (left column)
  const agendaItems = [
    { text: "Topic One", options: { bullet: true, breakLine: true, bold: true, fontSize: 16, fontFace: FONT_B, color: C.black } },
    { text: "Description of first topic", options: { breakLine: true, fontSize: 13, fontFace: FONT_B, color: C.bodyGray } },
    { text: "", options: { breakLine: true, fontSize: 8 } },
    { text: "Topic Two", options: { bullet: true, breakLine: true, bold: true, fontSize: 16, fontFace: FONT_B, color: C.black } },
    { text: "Description of second topic", options: { breakLine: true, fontSize: 13, fontFace: FONT_B, color: C.bodyGray } },
    { text: "", options: { breakLine: true, fontSize: 8 } },
    { text: "Topic Three", options: { bullet: true, breakLine: true, bold: true, fontSize: 16, fontFace: FONT_B, color: C.black } },
    { text: "Description of third topic", options: { fontSize: 13, fontFace: FONT_B, color: C.bodyGray } },
  ];
  s.addText(agendaItems, {
    x: M, y: 1.7, w: 5.5, h: 3.2,
    valign: "top",
  });

  // Right side: time/schedule block
  s.addShape("rect", {
    x: 6.5, y: 1.7, w: 3, h: 3.2,
    fill: { color: C.adobeLight },
    rectRadius: 0,
  });
  s.addText("Schedule", {
    x: 6.8, y: 1.9, w: 2.5, h: 0.4,
    fontSize: 16, fontFace: FONT_H, color: C.scuRed, bold: true, margin: 0,
  });
  s.addText([
    { text: "0:00 - 0:15   Welcome", options: { breakLine: true } },
    { text: "0:15 - 0:45   Topic One", options: { breakLine: true } },
    { text: "0:45 - 1:05   Topic Two", options: { breakLine: true } },
    { text: "1:05 - 1:15   Wrap-up", options: {} },
  ], {
    x: 6.8, y: 2.4, w: 2.5, h: 2.2,
    fontSize: 11, fontFace: FONT_B, color: C.bodyGray, valign: "top",
    paraSpaceAfter: 6,
  });

  addFooter(s, "CSEN 174  |  Week N", "Santa Clara University  |  Spring 2026");
}

// ────────────────────────────────────────────────────────────
// SLIDE 3: Section Divider (SCU Red background)
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.scuRed };

  s.addText("Section Title", {
    x: M, y: 1.5, w: 8, h: 1.2,
    fontSize: 40, fontFace: FONT_H, color: C.white, bold: true, margin: 0,
  });
  s.addText("Brief description or context for this section", {
    x: M, y: 2.8, w: 6, h: 0.6,
    fontSize: 16, fontFace: FONT_B, color: C.adobeLight, margin: 0,
  });

  // Gold accent
  s.addShape("rect", {
    x: M, y: 1.3, w: 1.5, h: 0.04,
    fill: { color: C.gold },
  });
}

// ────────────────────────────────────────────────────────────
// SLIDE 4: Content - Title + Bullets (standard lecture slide)
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.white };
  addLogoSmall(s, "color");

  s.addText("Content Slide Title", {
    x: M, y: 0.7, w: 9, h: 0.7,
    fontSize: 28, fontFace: FONT_H, color: C.black, bold: true, margin: 0,
  });

  // Left accent bar (shorter, aligned to content)
  s.addShape("rect", {
    x: M, y: 1.5, w: 0.05, h: 2.2,
    fill: { color: C.scuRed },
  });

  s.addText([
    { text: "First key point about the topic", options: { bullet: true, breakLine: true } },
    { text: "Second key point with supporting detail", options: { bullet: true, breakLine: true } },
    { text: "Third key point to reinforce the message", options: { bullet: true, breakLine: true } },
    { text: "Fourth point with actionable takeaway", options: { bullet: true } },
  ], {
    x: 0.8, y: 1.5, w: 8.5, h: 3.0,
    fontSize: 16, fontFace: FONT_B, color: C.bodyGray, valign: "top",
    paraSpaceAfter: 10,
  });

  addFooter(s, "CSEN 174  |  Week N", "Santa Clara University  |  Spring 2026");
}

// ────────────────────────────────────────────────────────────
// SLIDE 5: Two-Column Content
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.white };
  addLogoSmall(s, "color");

  s.addText("Two-Column Layout", {
    x: M, y: 0.7, w: 9, h: 0.7,
    fontSize: 28, fontFace: FONT_H, color: C.black, bold: true, margin: 0,
  });

  // Left column
  s.addShape("rect", {
    x: M, y: 1.5, w: 4.2, h: 3.2,
    fill: { color: C.nearWhite },
  });
  s.addText("Left Column Header", {
    x: 0.7, y: 1.65, w: 3.8, h: 0.4,
    fontSize: 16, fontFace: FONT_H, color: C.scuRed, bold: true, margin: 0,
  });
  s.addText([
    { text: "Supporting point one", options: { bullet: true, breakLine: true } },
    { text: "Supporting point two", options: { bullet: true, breakLine: true } },
    { text: "Supporting point three", options: { bullet: true } },
  ], {
    x: 0.7, y: 2.15, w: 3.8, h: 2.2,
    fontSize: 14, fontFace: FONT_B, color: C.bodyGray, valign: "top",
    paraSpaceAfter: 6,
  });

  // Right column
  s.addShape("rect", {
    x: 5.1, y: 1.5, w: 4.2, h: 3.2,
    fill: { color: C.nearWhite },
  });
  s.addText("Right Column Header", {
    x: 5.3, y: 1.65, w: 3.8, h: 0.4,
    fontSize: 16, fontFace: FONT_H, color: C.scuRed, bold: true, margin: 0,
  });
  s.addText([
    { text: "Supporting point one", options: { bullet: true, breakLine: true } },
    { text: "Supporting point two", options: { bullet: true, breakLine: true } },
    { text: "Supporting point three", options: { bullet: true } },
  ], {
    x: 5.3, y: 2.15, w: 3.8, h: 2.2,
    fontSize: 14, fontFace: FONT_B, color: C.bodyGray, valign: "top",
    paraSpaceAfter: 6,
  });

  addFooter(s, "CSEN 174  |  Week N", "Santa Clara University  |  Spring 2026");
}

// ────────────────────────────────────────────────────────────
// SLIDE 6: Stat Callout / Key Numbers
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.white };
  addLogoSmall(s, "color");

  s.addText("Key Numbers", {
    x: M, y: 0.7, w: 9, h: 0.6,
    fontSize: 28, fontFace: FONT_H, color: C.black, bold: true, margin: 0,
  });

  // Three stat boxes
  const stats = [
    { num: "12%", label: "Metric One" },
    { num: "25%", label: "Metric Two" },
    { num: "40%", label: "Metric Three" },
  ];

  stats.forEach((st, i) => {
    const xPos = M + 0.2 + (i * 3.1);
    s.addShape("rect", {
      x: xPos, y: 1.6, w: 2.7, h: 2.8,
      fill: { color: C.nearWhite },
    });
    // Red top accent
    s.addShape("rect", {
      x: xPos, y: 1.6, w: 2.7, h: 0.06,
      fill: { color: C.scuRed },
    });
    s.addText(st.num, {
      x: xPos, y: 2.0, w: 2.7, h: 1.2,
      fontSize: 54, fontFace: FONT_H, color: C.scuRed, bold: true,
      align: "center", valign: "middle", margin: 0,
    });
    s.addText(st.label, {
      x: xPos, y: 3.3, w: 2.7, h: 0.6,
      fontSize: 14, fontFace: FONT_B, color: C.bodyGray,
      align: "center", valign: "top", margin: 0,
    });
  });

  addFooter(s, "CSEN 174  |  Week N", "Santa Clara University  |  Spring 2026");
}

// ────────────────────────────────────────────────────────────
// SLIDE 7: Quote Slide
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.adobeLight };

  addLogoSmall(s, "color");

  // Large decorative quote mark (SCU Red for contrast on cream)
  s.addText("\u201C", {
    x: M, y: 0.9, w: 1, h: 1,
    fontSize: 80, fontFace: FONT_H, color: C.scuRed, margin: 0,
  });

  s.addText("This is a quote that captures a key insight or memorable statement from a reading, speaker, or discussion.", {
    x: 1.3, y: 1.5, w: 7.5, h: 2.0,
    fontSize: 22, fontFace: FONT_H, color: C.black, italic: true, margin: 0,
  });

  s.addText("\u2014  Attribution, Source", {
    x: 1.3, y: 3.6, w: 7, h: 0.4,
    fontSize: 14, fontFace: FONT_B, color: C.bodyGray, margin: 0,
  });

  addFooter(s, "CSEN 174  |  Week N", "Santa Clara University  |  Spring 2026");
}

// ────────────────────────────────────────────────────────────
// SLIDE 8: Image + Text (half-bleed layout)
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.white };

  // Left half: image placeholder
  s.addShape("rect", {
    x: 0, y: 0, w: 4.5, h: H,
    fill: { color: C.broncoRed },
  });
  s.addText("[ Image Placeholder ]", {
    x: 0, y: 2.2, w: 4.5, h: 1,
    fontSize: 16, fontFace: FONT_B, color: C.stone, align: "center", valign: "middle",
  });

  // Right half: content
  s.addText("Content with Image", {
    x: 5, y: 0.7, w: 4.5, h: 0.7,
    fontSize: 28, fontFace: FONT_H, color: C.black, bold: true, margin: 0,
  });

  s.addShape("rect", {
    x: 5, y: 1.45, w: 1.2, h: 0.04,
    fill: { color: C.gold },
  });

  s.addText([
    { text: "Key insight or point about the image", options: { bullet: true, breakLine: true } },
    { text: "Supporting detail or explanation", options: { bullet: true, breakLine: true } },
    { text: "Additional context or takeaway", options: { bullet: true } },
  ], {
    x: 5, y: 1.7, w: 4.5, h: 3.0,
    fontSize: 14, fontFace: FONT_B, color: C.bodyGray, valign: "top",
    paraSpaceAfter: 8,
  });

  addFooter(s, "CSEN 174  |  Week N", "Santa Clara University  |  Spring 2026");
}

// ────────────────────────────────────────────────────────────
// SLIDE 9: Discussion / Activity Prompt (dark background)
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.broncoRed };

  s.addText("Discussion", {
    x: M, y: 0.5, w: 3, h: 0.4,
    fontSize: 12, fontFace: FONT_B, color: C.gold,
    charSpacing: 4, margin: 0,
  });

  s.addText("Discussion prompt or activity\ninstruction goes here", {
    x: M, y: 1.2, w: 8, h: 2.0,
    fontSize: 32, fontFace: FONT_H, color: C.white, bold: true, margin: 0,
  });

  s.addText("Additional context, time allocation, or grouping instructions for the activity.", {
    x: M, y: 3.4, w: 7, h: 0.6,
    fontSize: 14, fontFace: FONT_B, color: C.stone, margin: 0,
  });

  // Bottom red bar
  s.addShape("rect", {
    x: 0, y: H - 0.06, w: W, h: 0.06,
    fill: { color: C.scuRed },
  });
}

// ────────────────────────────────────────────────────────────
// SLIDE 10: Numbered Steps / Process
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.white };
  addLogoSmall(s, "color");

  s.addText("Process or Steps", {
    x: M, y: 0.7, w: 9, h: 0.7,
    fontSize: 28, fontFace: FONT_H, color: C.black, bold: true, margin: 0,
  });

  const steps = [
    { n: "1", title: "Step One", desc: "Description of the first step in the process" },
    { n: "2", title: "Step Two", desc: "Description of the second step" },
    { n: "3", title: "Step Three", desc: "Description of the third step" },
    { n: "4", title: "Step Four", desc: "Description of the final step" },
  ];

  steps.forEach((st, i) => {
    const yPos = 1.6 + (i * 0.85);
    // Number badge (rectangle with red bg)
    s.addShape("rect", {
      x: M + 0.1, y: yPos + 0.05, w: 0.45, h: 0.45,
      fill: { color: C.scuRed },
      rectRadius: 0.22,
    });
    s.addText(st.n, {
      x: M + 0.1, y: yPos + 0.05, w: 0.45, h: 0.45,
      fontSize: 16, fontFace: FONT_B, color: C.white, bold: true,
      align: "center", valign: "middle", margin: 0,
    });
    // Title + description
    s.addText(st.title, {
      x: 1.3, y: yPos, w: 3, h: 0.35,
      fontSize: 16, fontFace: FONT_B, color: C.black, bold: true, margin: 0,
    });
    s.addText(st.desc, {
      x: 1.3, y: yPos + 0.32, w: 8, h: 0.35,
      fontSize: 13, fontFace: FONT_B, color: C.bodyGray, margin: 0,
    });
  });

  addFooter(s, "CSEN 174  |  Week N", "Santa Clara University  |  Spring 2026");
}

// ────────────────────────────────────────────────────────────
// SLIDE 11: Comparison / Before-After
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.white };
  addLogoSmall(s, "color");

  s.addText("Comparison", {
    x: M, y: 0.7, w: 9, h: 0.7,
    fontSize: 28, fontFace: FONT_H, color: C.black, bold: true, margin: 0,
  });

  // Left box (before / option A)
  s.addShape("rect", {
    x: M, y: 1.5, w: 4.2, h: 3.2,
    fill: { color: C.scuRed },
  });
  s.addText("Option A", {
    x: 0.7, y: 1.7, w: 3.8, h: 0.5,
    fontSize: 20, fontFace: FONT_H, color: C.white, bold: true, margin: 0,
  });
  s.addText([
    { text: "Characteristic one", options: { bullet: true, breakLine: true } },
    { text: "Characteristic two", options: { bullet: true, breakLine: true } },
    { text: "Characteristic three", options: { bullet: true } },
  ], {
    x: 0.7, y: 2.3, w: 3.8, h: 2.0,
    fontSize: 14, fontFace: FONT_B, color: C.adobeLight, valign: "top",
    paraSpaceAfter: 6,
  });

  // Right box (after / option B)
  s.addShape("rect", {
    x: 5.0, y: 1.5, w: 4.5, h: 3.2,
    fill: { color: C.black },
  });
  s.addText("Option B", {
    x: 5.2, y: 1.7, w: 4.0, h: 0.5,
    fontSize: 20, fontFace: FONT_H, color: C.white, bold: true, margin: 0,
  });
  s.addText([
    { text: "Characteristic one", options: { bullet: true, breakLine: true } },
    { text: "Characteristic two", options: { bullet: true, breakLine: true } },
    { text: "Characteristic three", options: { bullet: true } },
  ], {
    x: 5.2, y: 2.3, w: 4.0, h: 2.0,
    fontSize: 14, fontFace: FONT_B, color: C.fog, valign: "top",
    paraSpaceAfter: 6,
  });

  // Gold divider line between boxes instead of "vs" circle
  s.addShape("rect", {
    x: 4.75, y: 1.7, w: 0.04, h: 2.8,
    fill: { color: C.gold },
  });

  addFooter(s, "CSEN 174  |  Week N", "Santa Clara University  |  Spring 2026");
}

// ────────────────────────────────────────────────────────────
// SLIDE 12: Assignment / Work Time (action slide)
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.broncoRed };

  s.addText("Work Time", {
    x: M, y: 0.5, w: 3, h: 0.4,
    fontSize: 12, fontFace: FONT_B, color: C.gold,
    charSpacing: 4, margin: 0,
  });

  s.addText("Assignment Title", {
    x: M, y: 1.2, w: 8, h: 1.0,
    fontSize: 36, fontFace: FONT_H, color: C.white, bold: true, margin: 0,
  });

  s.addText([
    { text: "Task one: description of what to do", options: { bullet: true, breakLine: true } },
    { text: "Task two: another deliverable or action", options: { bullet: true, breakLine: true } },
    { text: "Task three: final item", options: { bullet: true } },
  ], {
    x: M, y: 2.5, w: 8, h: 2.0,
    fontSize: 15, fontFace: FONT_B, color: C.fog, valign: "top",
    paraSpaceAfter: 8,
  });

  // Bottom bars
  s.addShape("rect", {
    x: 0, y: H - 0.35, w: W, h: 0.02,
    fill: { color: C.scuRed },
  });
  s.addText("CSEN 174  |  Kai Lukoff  |  Santa Clara University  |  Spring 2026", {
    x: M, y: H - 0.33, w: 9, h: 0.28,
    fontSize: 8, fontFace: FONT_B, color: C.stone, valign: "middle", margin: 0,
  });
}

// ────────────────────────────────────────────────────────────
// SLIDE 13: Closing / Thank You
// ────────────────────────────────────────────────────────────
{
  const s = pres.addSlide();
  s.background = { color: C.scuRed };

  // Top accent
  s.addShape("rect", {
    x: 0, y: 0, w: W, h: 0.06,
    fill: { color: C.gold },
  });

  // White logo centered
  s.addImage({
    data: logoWhiteB64,
    x: 3.5, y: 0.6, w: 3, h: 0.98,
    sizing: { type: "contain", w: 3, h: 0.98 },
  });

  s.addText("Questions?", {
    x: 1, y: 2.0, w: 8, h: 1.2,
    fontSize: 44, fontFace: FONT_H, color: C.white, bold: true,
    align: "center", valign: "middle", margin: 0,
  });

  s.addText("presenter@scu.edu  |  Office Location  |  Office Hours", {
    x: 1, y: 3.5, w: 8, h: 0.5,
    fontSize: 14, fontFace: FONT_B, color: C.adobeLight,
    align: "center", margin: 0,
  });

  // Bottom accent
  s.addShape("rect", {
    x: 0, y: H - 0.06, w: W, h: 0.06,
    fill: { color: C.gold },
  });
}

// ============================================================
// SAVE
// ============================================================
const outPath = path.join(__dirname, "..", "SCU-Template.pptx");
pres.writeFile({ fileName: outPath })
  .then(() => console.log("Saved: " + outPath))
  .catch(err => console.error(err));

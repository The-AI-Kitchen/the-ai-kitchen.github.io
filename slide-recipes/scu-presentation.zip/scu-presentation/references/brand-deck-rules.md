# SCU Presentation Template: Brand Deck Rules

Use this document as the authoritative reference when creating or editing Santa Clara University slide decks. Slide 1 in the .potx is a font-setup instruction slide and should be deleted before presenting.

---

## Brand Color Palette

| Token | Hex | Role |
|-------|-----|------|
| SCU Red | #A32035 | Primary brand red (PMS 201 C). Backgrounds on title, section, discussion, work-time, and closing slides. Card borders (2pt) on light slides. Left rule bars. Number badges. |
| Bronco Red | #862633 | Darker red (PMS 202 C). Right-panel accent on title/section/closing slides. Comparison box B fill. |
| Stone | #758592 | Neutral gray (PMS 7544 C). Available but not used in current template. |
| Fog | #E0DAD3 | Warm light gray. Available for subtle backgrounds. |
| Fog Light | #EFECE9 | Lighter warm gray. Available for card fills as alternative to white. |
| Adobe | #F1E7CC | Warm cream. Available for backgrounds. |
| Adobe Light | #F8F3E5 | Lighter cream. Default background for all content (light) slides. |
| Clay | #C2A98B | Warm tan. Available as accent. |
| Slate | #425766 | Dark blue-gray. Available for text. |
| Slate Dark | #2A373F | Darkest neutral. Available for text. |
| Slate Light | #D0D5D9 | Light blue-gray. Available for backgrounds. |
| Gold | #FFB600 | Accent only. Short underline rules beneath titles (on both dark and light slides). Bottom bar on closing slide. Never used as a background or text color. |
| Black | #000000 | Card header text on light slides. |
| Body Gray | #555555 | Body/bullet text on light slides. |
| White | #FFFFFF | All text on dark (red) backgrounds. Card fills on light slides. |

The current template actively uses: SCU Red, Bronco Red, Adobe Light, Gold, Black, Body Gray, White. The remaining palette colors (Stone, Fog, Fog Light, Adobe, Clay, Slate, Slate Dark, Slate Light) are part of the SCU brand and available if needed, but are not present in any template slide by default.

---

## Typography

SCU has two tiers of brand fonts. Use Primary if installed; otherwise fall back to Secondary.

| Tier | Sans-serif (headers) | Serif (body) |
|------|---------------------|-------------|
| Primary (official brand) | Santa Clara Nueva | Minion Pro |
| Secondary (free Google Fonts) | Figtree | Crimson Pro |

The current .potx template uses Figtree + Crimson Pro so the deck works on any machine without licensed font installs. If Santa Clara Nueva and Minion Pro are available, prefer them.

| Role | Font family | Weight | Size |
|------|------------|--------|------|
| Slide titles | Sans-serif (Figtree / Santa Clara Nueva) | Bold (700) | 36-44pt |
| Category labels ("Discussion", "Work Time") | Sans-serif | Semibold (600), uppercase, letter-spaced | 16-20pt |
| Section headers within a slide | Sans-serif | Bold (700) | 24-28pt |
| Body text, bullets, descriptions | Serif (Crimson Pro / Minion Pro) | Medium (500) | 16-18pt |
| Large stat numbers | Serif | Black (900) | 60-72pt |
| Captions, footnotes, schedule text | Serif | Medium (500) | 14pt (minimum) |

Key sizing rules:
- Never set any font below 14pt
- Title must be at least 1.75x body size
- Title and section divider slides: centered titles. Content slides: left-aligned titles.

---

## Slide Inventory (14 slides)

### Slide 1: Font Setup Instructions (DELETE BEFORE PRESENTING)
- Background: SCU Red (#A32035)
- Purpose: Tells the user to install Figtree and Crimson Pro from Google Fonts
- Action: Remove this slide from every final deck

### Slide 2: Title Slide
- Background: SCU Red, with a slightly darker Bronco Red right panel (approx 25% width)
- SCU white logo: top-left corner
- Title: Figtree Bold, white, large (approx 44pt), left-aligned in left 70%
- Subtitle: Crimson Pro Medium, white, below title
- Gold accent line: short horizontal rule below subtitle
- Presenter line: Crimson Pro Medium, white, "Name | Department | Date"
- Use for: First slide of every deck

### Slide 3: Today's Session / Agenda
- Background: Adobe Light (#F8F3E5)
- SCU color logo: top-left, small
- Title: Figtree Bold, black, with gold underline
- Left column: bulleted topic list (Crimson Pro Medium, bold topic names + gray descriptions)
- Right column: "Schedule" card with rounded corners, Bronco Red border, white fill. Time entries in Crimson Pro Medium.
- Use for: Class agenda, meeting agenda, session overview

### Slide 4: Section Divider
- Background: SCU Red, with darker Bronco Red right panel
- SCU white logo: top-left
- Gold accent line: short horizontal rule below logo area
- Section title: Figtree Bold, white, large
- Description: Crimson Pro Medium, white, smaller
- Use for: Transitioning between major topics

### Slide 5: Content (Single Column with Left Border)
- Background: Adobe Light (#F8F3E5)
- SCU color logo: top-left, small
- Title: Figtree Bold, black, large
- SCU Red vertical rule bar: left edge of bullet area
- Bullets: Crimson Pro Medium, Body Gray (#555555), with round bullet markers
- Use for: Standard content slides, key points, explanations

### Slide 6: Two-Column Layout
- Background: Adobe Light (#F8F3E5)
- SCU color logo: top-left, small
- Title: Figtree Bold, black
- Two cards: rounded corners, Bronco Red (#862633) border, white fill
- Card headers: Figtree Bold, SCU Red
- Card body: Crimson Pro Medium, Body Gray, bulleted
- Use for: Side-by-side concepts, pros/cons, before/after

### Slide 7: Key Numbers / Stats
- Background: Adobe Light (#F8F3E5)
- SCU color logo: top-left, small
- Title: Figtree Bold, black
- Three stat cards: rounded corners, Bronco Red border, white fill
- Stat number: Crimson Pro Black (900 weight), SCU Red, very large (approx 60-72pt)
- Metric label: Crimson Pro Medium, Body Gray, below number
- Use for: Data highlights, survey results, impact metrics

### Slide 8: Quote
- Background: Adobe Light (#F8F3E5)
- SCU color logo: top-left, small
- Large decorative quotation mark: SCU Red, top-left of quote area
- Quote text: Crimson Pro Medium, black, italic, large (approx 24-28pt)
- Attribution: Crimson Pro Medium, Body Gray, preceded by em dash
- Use for: Featured quotes from readings, speakers, research

### Slide 9: Content with Image (Split Layout)
- Left half: Bronco Red (#862633) background, image placeholder centered, white placeholder text
- Right half: Adobe Light (#F8F3E5) background
- SCU color logo: top-right of right panel
- Title: Figtree Bold, black, right panel
- Gold accent line: short underline below title
- Bullets: Crimson Pro Medium, Body Gray, right panel
- Use for: Showing a photo, diagram, or screenshot alongside talking points

### Slide 10: Discussion Prompt
- Background: SCU Red, with darker Bronco Red right panel
- SCU white logo: top-right
- Category label: "Discussion" in Figtree Semibold, white, uppercase/spaced, with SCU Red underline
- Prompt text: Figtree Bold, white, large
- Context line: Crimson Pro Medium, white, smaller
- Use for: In-class discussion questions, think-pair-share prompts

### Slide 11: Process or Steps
- Background: Adobe Light (#F8F3E5)
- SCU color logo: top-left, small
- Title: Figtree Bold, black
- Numbered steps: SCU Red rounded-rectangle badges with white number (Crimson Pro Black), paired with step name (Figtree Bold, black) and description (Crimson Pro Medium, Body Gray)
- Use for: Workflows, methodologies, instructions, design processes

### Slide 12: Comparison
- Background: Adobe Light (#F8F3E5)
- SCU color logo: top-left, small
- Title: Figtree Bold, black
- Two large cards with rounded corners: both use SCU Red/Bronco Red fills, white text
- Left card (Option A): SCU Red fill
- Right card (Option B): Bronco Red fill
- Card headers: Figtree Bold, white
- Card bullets: Crimson Pro Medium, white
- Use for: Comparing two frameworks, tools, approaches

### Slide 13: Work Time / Assignment
- Background: SCU Red, with darker Bronco Red right panel
- SCU white logo: top-right
- Category label: "Work Time" in Figtree Semibold, white, uppercase/spaced, with gold underline
- Assignment title: Figtree Bold, white, large
- Task bullets: Crimson Pro Medium, white
- Use for: In-class work sessions, lab instructions, assignment introductions

### Slide 14: Closing / Questions
- Background: SCU Red, with darker Bronco Red right panel
- SCU logo: large, centered, white version
- "Questions?" text: Figtree Bold, white, very large, centered
- Contact line: Crimson Pro Medium, white, "email | office | hours"
- Gold accent bar: full-width at slide bottom
- Use for: Final slide of every deck

---

## Design Rules

### Slide backgrounds and branding
- Dark slides (title, section, discussion, work time, closing) use SCU Red background with a Bronco Red right accent panel
- Light slides (all content types) use Adobe Light (#F8F3E5) background
- SCU white logo on dark slides, color logo on light slides
- Gold (#FFB600) only for short accent lines and the closing slide's bottom bar, never for backgrounds or large areas
- No shield watermarks, background patterns, or gradients
- No footers: do not include course info, university name, or bottom rule lines on content slides. Keep slides clean.

### Cards and shapes
- Cards on light slides: white (#FFFFFF) fill, rounded corners, 2pt SCU Red (#A32035) border
- Comparison cards: SCU Red fill (Option A) and Bronco Red fill (Option B), white text, no border needed
- Left vertical rule bar (SCU Red) on single-column content slides
- Number badges: SCU Red rounded rectangles with white text

### Spacing, margins, and coverage
- Safe content area: 0.5" (36pt) margin on all sides
- Content should cover at least 70% of the safe area (don't leave large empty gaps)
- The lowest element should land within ~36pt of the bottom margin, not cluster in the top half
- Inset text inside shapes by 10-15pt so text doesn't touch edges
- 0.3-0.5" gaps between content blocks, consistent within a slide

### Content density
- Maximum 3-4 key points per slide with short supporting text
- Prefer more slides with less content over fewer dense slides
- Maximum 4-5 bullet points per slide

### Text and bullet formatting
- Bullet text is left-aligned; titles are left-aligned on content slides, centered on title/closing slides
- Use round bullet characters for list items
- Standard bullet indent: 36pt margin with hanging indent
- Sub-bullets indented one additional level

### Layout variety
- Rotate layouts across the deck: don't use the same slide type 3+ consecutive times
- Map content to the best slide type (see Slide Selection Guide below)

### Contrast and accessibility
- Maintain WCAG AA 4.5:1 minimum contrast ratio
- White text on SCU Red/Bronco Red backgrounds meets this requirement
- Body Gray (#555555) on Adobe Light (#F8F3E5) meets this requirement
- Never use light text on light backgrounds or dark text on dark backgrounds

---

## Slide Selection Guide

| Content type | Use slide |
|---|---|
| Opening a presentation | 2 (Title) |
| Agenda or session plan | 3 (Today's Session) |
| Starting a new topic | 4 (Section Divider) |
| Teaching a concept | 5 (Content) |
| Comparing two things side by side | 6 (Two-Column) or 12 (Comparison) |
| Highlighting data or metrics | 7 (Key Numbers) |
| Featuring a quote | 8 (Quote) |
| Showing an image with context | 9 (Content with Image) |
| Posing a discussion question | 10 (Discussion) |
| Explaining a process | 11 (Steps) |
| Assigning in-class work | 13 (Work Time) |
| Ending a presentation | 14 (Closing) |

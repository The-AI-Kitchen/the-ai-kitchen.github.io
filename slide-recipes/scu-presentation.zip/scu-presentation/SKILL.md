---
name: scu-presentation
description: >
  Create or convert Santa Clara University slide decks that follow the official SCU brand template.
  Use this skill whenever the user asks to make a presentation, slide deck, lecture slides, or talks
  about creating slides for a class, meeting, or talk at SCU. Also trigger when the user uploads an
  existing .pptx and wants it reformatted or converted to match the SCU template. Trigger phrases
  include: "make me a deck", "create slides for", "build a presentation", "convert this deck",
  "reformat these slides", "SCU slides", "lecture slides for week", or any mention of creating a
  .pptx for an SCU context. This skill should take priority over the generic pptx skill when the
  content is for Santa Clara University.
---

# SCU Presentation Skill

This skill generates on-brand Santa Clara University presentations using PptxGenJS. It handles two workflows:

- **New deck**: Given a topic, outline, or content, generate a complete .pptx from scratch
- **Conversion**: Given an existing .pptx, extract its content and rebuild it using the SCU template

## Before you start

1. Read `references/brand-deck-rules.md` for the complete brand spec (colors, fonts, slide types, design rules)
2. Read `references/build-template.js` to see the reference implementation of every slide type
3. Read the pptx skill's `pptxgenjs.md` for PptxGenJS API details

## Workflow: New Deck

### Step 1: Plan the slide sequence

Map the user's content to specific slide types from the template inventory. Every deck should follow this structure:

- Start with a Title Slide (template slide 2)
- Follow with a Today's Session / Agenda slide (template slide 3) if there are 3+ topics
- Use Section Dividers (template slide 4) to break between major topics
- Fill in content using the appropriate slide type for each piece of content (see the Slide Selection Guide in brand-deck-rules.md)
- End with a Closing slide (template slide 14)

Vary the layouts. Never use the same slide type more than 2 consecutive times. Aim for visual rhythm: content slide, then a stat or image slide, then content, then a quote, etc.

### Step 2: Write the PptxGenJS build script

Create a Node.js script that generates the deck. Use the reference `build-template.js` as your starting point for:
- The exact color constants (the `C` object)
- The font constants (`FONT_H` for headers, `FONT_B` for body)
- Helper functions like `addFooter()` and `addLogoSmall()`
- The slide dimensions (10" x 5.625" for 16:9)

For each slide, replicate the visual structure from the corresponding template slide type. The reference script has working implementations of all 13 slide types (excluding the font-setup slide).

Key implementation details:
- Embed the SCU logos as base64 from the logo PNG files (color and white versions)
- Use `rectRadius` for rounded corners on cards (0.15-0.2 range)
- Cards on light slides: white fill, 2pt SCU Red border (`{ color: C.scuRed, size: 2 }`)
- Dark slides: SCU Red background with a Bronco Red right-panel rectangle (approx 25% width)
- Gold accent lines: thin rectangles, height 0.03-0.04", Gold fill
- **No footers**: Do not add course info or university footers. Keep slides clean and uncluttered. The thin SCU Red bottom rule line is also omitted.

### Avoiding common layout bugs

Two-column and comparison slides are the most overflow-prone. Follow these rules:

- **Total card width must fit inside margins.** With 0.5" margins on a 10" slide, you have 9" of usable width. Two cards with a gap between them: each card should be at most 4.3" wide with a 0.4" gap.
- **Set explicit `w` on every text box inside a card.** If the text box is wider than the card, text will extend past the card border or off-slide. The text box width should be the card width minus ~0.4" for internal padding.
- **Right-side card x-position**: calculate as `left_card_x + left_card_w + gap`. Never hardcode it without checking that `x + w ≤ 9.5` (the right margin boundary).
- **Bullet text word wrap**: always set `wrap: true` on text elements. Long lines that don't wrap will overflow.

### Font rendering note

Figtree and Crimson Pro are Google Fonts that must be installed on the machine opening the .pptx. In sandbox/headless environments (like Cowork's LibreOffice), they fall back to system fonts (Trebuchet MS, Georgia), which looks generic. The fonts will render correctly when the user opens the file in PowerPoint with the fonts installed. Always declare `fontFace: "Figtree"` and `fontFace: "Crimson Pro"` explicitly on every text element regardless, so the font metadata is correct in the file.

### Step 3: Build and QA

```bash
# Install pptxgenjs if needed
cd <working-dir> && npm init -y && npm install pptxgenjs

# Run the build script
node build-deck.js

# Convert to images for visual inspection
soffice --headless --convert-to pdf output.pptx
pdftoppm -jpeg -r 150 output.pdf slide
```

Inspect every slide image. Check for:
- Overlapping text or elements
- Text overflow or cut-off
- Wrong colors or fonts
- Inconsistent spacing
- Missing logos or accent lines
- Content that doesn't match the template slide type

Fix issues and rebuild until clean. Use a subagent for visual QA if available.

### Step 4: Deliver

Copy the final .pptx to the workspace folder and provide a link.

## Workflow: Convert Existing Deck

### Step 1: Analyze the source deck

```bash
python -m markitdown source.pptx
```

Extract all text content, noting slide order and content type for each slide.

### Step 2: Map slides to template types

For each slide in the source deck, determine the best matching template slide type:
- Slides with just a title and bullets → Content (template 5)
- Slides with two columns → Two-Column (template 6) or Comparison (template 12)
- Slides with big numbers → Key Numbers (template 7)
- Slides with a quote → Quote (template 8)
- Slides with an image + text → Content with Image (template 9)
- Slides that pose a question → Discussion (template 10)
- Slides showing a process → Steps (template 11)
- Activity/assignment slides → Work Time (template 13)

Add Section Dividers where topic shifts occur. Add an Agenda slide if the source doesn't have one and there are 3+ topics.

### Step 3: Generate and QA

Follow the same build and QA process as the New Deck workflow, but populate each slide with the extracted content from the source deck.

## Color Reference (quick lookup)

```
SCU Red:     A32035    Bronco Red:  862633
Adobe Light: F8F3E5    Gold:        FFB600
Black:       000000    Body Gray:   555555
White:       FFFFFF    Fog:         E0DAD3
```

## Font Reference (quick lookup)

```
Headers:  Figtree Bold (700)         — fallback: Santa Clara Nueva, Avenir Next
Body:     Crimson Pro Medium (500)   — fallback: Minion Pro, Georgia
Stats:    Crimson Pro Black (900)
Labels:   Figtree Semibold (600), uppercase, letter-spaced
Min size: 14pt (never go below)
```

## Sizing Reference (quick lookup)

```
Slide titles:     36-44pt
Section headers:  24-28pt
Body text:        16-18pt
Captions:         14pt (floor)
Margins:          0.5" (36pt) all sides
Card text inset:  10-15pt
Content coverage: ≥70% of safe area
```
